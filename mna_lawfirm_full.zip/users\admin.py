from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User

class UserAdmin(BaseUserAdmin):
    fieldsets = BaseUserAdmin.fieldsets + (
        ('Role Info', {'fields': ('role', 'sub_role', 'phone_number', 'profile_picture')}),
    )
    list_display = BaseUserAdmin.list_display + ('role', 'sub_role', 'phone_number')
    list_filter = BaseUserAdmin.list_filter + ('role', 'sub_role')

admin.site.register(User, UserAdmin)

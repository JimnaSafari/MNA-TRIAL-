from django.db import models
from users.models import User

# Create your models here.

class LeaveRequest(models.Model):
    LEAVE_TYPE_CHOICES = [
        ('annual', 'Annual'),
        ('sick', 'Sick'),
        ('study', 'Study'),
        ('maternity', 'Maternity'),
        ('paternity', 'Paternity'),
        ('compassionate', 'Compassionate'),
        ('other', 'Other'),
    ]
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
        ('cancelled', 'Cancelled'),
    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='leave_requests')
    leave_type = models.CharField(max_length=20, choices=LEAVE_TYPE_CHOICES)
    other_reason = models.CharField(max_length=255, blank=True, null=True, help_text='Specify if leave type is Other')
    start_date = models.DateField()
    end_date = models.DateField()
    reason = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    date_requested = models.DateTimeField(auto_now_add=True)
    date_responded = models.DateTimeField(blank=True, null=True)
    comments = models.TextField(blank=True, null=True)

    # Approval chain
    APPROVAL_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    senior_partner_approval = models.CharField(max_length=20, choices=APPROVAL_CHOICES, default='pending')
    senior_partner_approval_date = models.DateTimeField(blank=True, null=True)
    managing_partner_approval = models.CharField(max_length=20, choices=APPROVAL_CHOICES, default='pending')
    managing_partner_approval_date = models.DateTimeField(blank=True, null=True)
    hr_approval = models.CharField(max_length=20, choices=APPROVAL_CHOICES, default='pending')
    hr_approval_date = models.DateTimeField(blank=True, null=True)

    def __str__(self):
        return f"{self.user.get_full_name()} - {self.leave_type} ({self.start_date} to {self.end_date})"

from django import forms
from .models import Billing

class BillingForm(forms.ModelForm):
    class Meta:
        model = Billing
        fields = [
            'client', 'case', 'issued_by', 'amount', 'description', 'status',
            'invoice_number', 'due_date', 'date_paid', 'tags', 'invoice_file'
        ]
        widgets = {
            'due_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'date_paid': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'description': forms.Textarea(attrs={'rows': 3, 'class': 'form-control'}),
            'tags': forms.TextInput(attrs={'placeholder': 'e.g. retainer, urgent', 'class': 'form-control'}),
        } 
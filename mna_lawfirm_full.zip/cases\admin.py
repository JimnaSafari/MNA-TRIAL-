from django.contrib import admin
from .models import Case

@admin.register(Case)
class CaseAdmin(admin.ModelAdmin):
    list_display = (
        'title', 'case_number', 'client', 'status', 'is_ongoing', 'main_advocate', 'next_hearing_date'
    )
    list_filter = ('status', 'court', 'is_ongoing', 'main_advocate')
    search_fields = ('title', 'case_number', 'client__user__username', 'court', 'case_brief', 'last_court_update', 'required_documents')

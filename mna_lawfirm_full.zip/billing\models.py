from django.db import models
from cases.models import Case
from clients.models import Client
from users.models import User
from django.core.exceptions import ValidationError

class Billing(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('paid', 'Paid'),
        ('overdue', 'Overdue'),
    ]
    case = models.ForeignKey(Case, on_delete=models.CASCADE, related_name='billings', null=True, blank=True)
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='billings', null=True, blank=True)
    issued_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='issued_billings')
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    description = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    invoice_number = models.CharField(max_length=100, unique=True)
    due_date = models.DateField(blank=True, null=True)
    date_issued = models.DateField(auto_now_add=True)
    date_paid = models.DateField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    tags = models.CharField(max_length=255, blank=True, help_text="Comma-separated tags for this billing entry.")
    invoice_file = models.FileField(upload_to='invoices/', null=True, blank=True, help_text="Upload invoice (PDF, max 10MB)")

    def __str__(self):
        return f"Invoice {self.invoice_number} - {self.client} - {self.amount}"

    def clean(self):
        super().clean()
        if self.invoice_file:
            if not self.invoice_file.name.lower().endswith('.pdf'):
                raise ValidationError({'invoice_file': 'Only PDF files are allowed.'})
            if self.invoice_file.size > 10 * 1024 * 1024:
                raise ValidationError({'invoice_file': 'File size must be under 10MB.'})

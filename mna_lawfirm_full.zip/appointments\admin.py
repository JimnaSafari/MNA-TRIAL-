from django.contrib import admin
from .models import Appointment

@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('title', 'case', 'client', 'advocate', 'start_time', 'end_time', 'is_virtual', 'location')
    list_filter = ('is_virtual', 'start_time', 'advocate')
    search_fields = ('title', 'case__title', 'client__user__username', 'advocate__username', 'location')

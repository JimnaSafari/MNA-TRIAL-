from django.contrib import admin
from .models import Reminder

@admin.register(Reminder)
class ReminderAdmin(admin.ModelAdmin):
    list_display = ('user', 'case', 'appointment', 'title', 'remind_at', 'is_sent', 'sent_at')
    list_filter = ('is_sent', 'remind_at', 'user')
    search_fields = ('title', 'description', 'case__title', 'appointment__title', 'user__username')

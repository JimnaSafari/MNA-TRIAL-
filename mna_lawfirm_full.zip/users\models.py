from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    ROLE_CHOICES = [
        ('admin', 'Admin'),
        ('advocate', 'Advocate'),
        ('client', 'Client'),
    ]
    SUBROLE_CHOICES = [
        ('associate', 'Associate'),
        ('intern', 'Intern'),
        ('office_assistant', 'Office Assistant'),
    ]

    role = models.CharField(max_length=20, choices=ROLE_CHOICES)
    sub_role = models.CharField(max_length=20, choices=SUBROLE_CHOICES, blank=True, null=True)
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    profile_picture = models.ImageField(upload_to='profile_pics/', blank=True, null=True)

    def save(self, *args, **kwargs):
        if self.role != 'advocate':
            self.sub_role = None
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.username} ({self.get_role_display()})"

from django.db import models
from clients.models import Client
from users.models import User

class Case(models.Model):
    STATUS_CHOICES = [
        ('open', 'Open'),
        ('closed', 'Closed'),
        ('pending', 'Pending'),
        ('appeal', 'On Appeal'),
    ]

    title = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='cases')
    advocates = models.ManyToManyField(User, related_name='cases')
    main_advocate = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='main_cases', help_text='Primary advocate handling the case')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='open')
    is_ongoing = models.BooleanField(default=True, help_text='Is this case ongoing?')
    case_number = models.CharField(max_length=100, unique=True)
    court = models.CharField(max_length=255, blank=True, null=True)
    date_filed = models.DateField(blank=True, null=True)
    next_hearing_date = models.DateField(blank=True, null=True)
    case_brief = models.TextField(blank=True, null=True, help_text='A brief of what the file is about')
    last_court_update = models.TextField(blank=True, null=True, help_text='What happened in court the last time')
    required_documents = models.TextField(blank=True, null=True, help_text='Any documents required to be filed')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} ({self.case_number})"

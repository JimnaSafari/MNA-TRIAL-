from django.db import models
from cases.models import Case
from clients.models import Client
from users.models import User

class Appointment(models.Model):
    case = models.ForeignKey(Case, on_delete=models.CASCADE, related_name='appointments', null=True, blank=True)
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='appointments', null=True, blank=True)
    advocate = models.ForeignKey(User, on_delete=models.CASCADE, related_name='appointments')
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    location = models.CharField(max_length=255, blank=True, null=True)
    is_virtual = models.BooleanField(default=False)
    virtual_link = models.URLField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} ({self.start_time:%Y-%m-%d %H:%M})"

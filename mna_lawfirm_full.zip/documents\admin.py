from django.contrib import admin
from .models import Document

@admin.register(Document)
class DocumentAdmin(admin.ModelAdmin):
    list_display = ('title', 'document_type', 'case', 'client', 'uploaded_by', 'date_uploaded', 'is_confidential', 'tags')
    list_filter = ('document_type', 'is_confidential', 'required_for_case', 'date_uploaded')
    search_fields = ('title', 'description', 'case__title', 'client__user__username', 'uploaded_by__username', 'tags')

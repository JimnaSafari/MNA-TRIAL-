from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse
from clients.models import Client
from users.models import User
from django.contrib import messages
from django import forms
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.http import HttpResponseRedirect
from django.contrib.auth.decorators import login_required, user_passes_test
from cases.models import Case
from documents.models import Document

class ClientForm(forms.ModelForm):
    class Meta:
        model = Client
        fields = ['user', 'address', 'phone_number', 'email', 'organization']

class UserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name', 'role', 'sub_role', 'phone_number', 'profile_picture', 'is_active']

class CaseForm(forms.ModelForm):
    class Meta:
        model = Case
        fields = ['title', 'description', 'client', 'advocates', 'main_advocate', 'status', 'is_ongoing', 'case_number', 'court', 'date_filed', 'next_hearing_date', 'case_brief', 'last_court_update', 'required_documents']
        widgets = {
            'advocates': forms.CheckboxSelectMultiple,
            'date_filed': forms.DateInput(attrs={'type': 'date'}),
            'next_hearing_date': forms.DateInput(attrs={'type': 'date'}),
        }

class DocumentForm(forms.ModelForm):
    class Meta:
        model = Document
        fields = ['title', 'file', 'case', 'client', 'uploaded_by', 'document_type', 'description', 'is_confidential', 'required_for_case', 'tags']

# Helper to check admin
admin_required = user_passes_test(lambda u: u.is_authenticated and u.role == 'admin')

def dashboard(request):
    return render(request, 'dashboard.html')

def clients_list(request):
    clients = Client.objects.select_related('user').all()
    return render(request, 'clients_list.html', {'clients': clients})

def client_create(request):
    if request.method == 'POST':
        form = ClientForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Client created successfully!')
            return redirect('clients_list')
    else:
        form = ClientForm()
    return render(request, 'client_form.html', {'form': form, 'action': 'Create'})

def client_update(request, pk):
    client = get_object_or_404(Client, pk=pk)
    if request.method == 'POST':
        form = ClientForm(request.POST, instance=client)
        if form.is_valid():
            form.save()
            messages.success(request, 'Client updated successfully!')
            return redirect('clients_list')
    else:
        form = ClientForm(instance=client)
    return render(request, 'client_form.html', {'form': form, 'action': 'Edit'})

def client_delete(request, pk):
    client = get_object_or_404(Client, pk=pk)
    if request.method == 'POST':
        client.delete()
        messages.success(request, 'Client deleted successfully!')
        return redirect('clients_list')
    return render(request, 'client_confirm_delete.html', {'client': client})

def custom_login(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('dashboard')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

def custom_logout(request):
    logout(request)
    return HttpResponseRedirect('/accounts/login/')

@login_required
def user_profile(request):
    user = request.user
    if request.method == 'POST':
        form = UserForm(request.POST, request.FILES, instance=user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('user_profile')
    else:
        form = UserForm(instance=user)
    return render(request, 'user_profile.html', {'form': form})

@admin_required
def user_list(request):
    users = User.objects.all()
    return render(request, 'user_list.html', {'users': users})

@admin_required
def user_create(request):
    if request.method == 'POST':
        form = UserForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'User created successfully!')
            return redirect('user_list')
    else:
        form = UserForm()
    return render(request, 'user_form.html', {'form': form, 'action': 'Create'})

@admin_required
def user_update(request, pk):
    user = get_object_or_404(User, pk=pk)
    if request.method == 'POST':
        form = UserForm(request.POST, request.FILES, instance=user)
        if form.is_valid():
            form.save()
            messages.success(request, 'User updated successfully!')
            return redirect('user_list')
    else:
        form = UserForm(instance=user)
    return render(request, 'user_form.html', {'form': form, 'action': 'Edit'})

@admin_required
def user_delete(request, pk):
    user = get_object_or_404(User, pk=pk)
    if request.method == 'POST':
        user.delete()
        messages.success(request, 'User deleted successfully!')
        return redirect('user_list')
    return render(request, 'user_confirm_delete.html', {'user_obj': user})

@login_required
def cases_list(request):
    cases = Case.objects.select_related('client').all()
    return render(request, 'cases_list.html', {'cases': cases})

@login_required
def case_create(request):
    if request.method == 'POST':
        form = CaseForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Case created successfully!')
            return redirect('cases_list')
    else:
        form = CaseForm()
    return render(request, 'case_form.html', {'form': form, 'action': 'Create'})

@login_required
def case_detail(request, pk):
    case = get_object_or_404(Case, pk=pk)
    return render(request, 'case_detail.html', {'case': case})

@login_required
def case_update(request, pk):
    case = get_object_or_404(Case, pk=pk)
    if request.method == 'POST':
        form = CaseForm(request.POST, instance=case)
        if form.is_valid():
            form.save()
            messages.success(request, 'Case updated successfully!')
            return redirect('cases_list')
    else:
        form = CaseForm(instance=case)
    return render(request, 'case_form.html', {'form': form, 'action': 'Edit'})

@login_required
def case_delete(request, pk):
    case = get_object_or_404(Case, pk=pk)
    if request.method == 'POST':
        case.delete()
        messages.success(request, 'Case deleted successfully!')
        return redirect('cases_list')
    return render(request, 'case_confirm_delete.html', {'case': case})

@login_required
def documents_list(request):
    documents = Document.objects.select_related('case', 'client', 'uploaded_by').all()
    return render(request, 'documents_list.html', {'documents': documents})

@login_required
def document_create(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'Document uploaded successfully!')
            return redirect('documents_list')
    else:
        form = DocumentForm()
    return render(request, 'document_form.html', {'form': form, 'action': 'Upload'})

@login_required
def document_detail(request, pk):
    document = get_object_or_404(Document, pk=pk)
    return render(request, 'document_detail.html', {'document': document})

@login_required
def document_update(request, pk):
    document = get_object_or_404(Document, pk=pk)
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES, instance=document)
        if form.is_valid():
            form.save()
            messages.success(request, 'Document updated successfully!')
            return redirect('documents_list')
    else:
        form = DocumentForm(instance=document)
    return render(request, 'document_form.html', {'form': form, 'action': 'Edit'})

@login_required
def document_delete(request, pk):
    document = get_object_or_404(Document, pk=pk)
    if request.method == 'POST':
        document.delete()
        messages.success(request, 'Document deleted successfully!')
        return redirect('documents_list')
    return render(request, 'document_confirm_delete.html', {'document': document}) 
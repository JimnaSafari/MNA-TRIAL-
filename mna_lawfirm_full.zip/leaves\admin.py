from django.contrib import admin
from .models import LeaveRequest

@admin.register(LeaveRequest)
class LeaveRequestAdmin(admin.ModelAdmin):
    list_display = (
        'user', 'leave_type', 'other_reason', 'start_date', 'end_date', 'status',
        'senior_partner_approval', 'managing_partner_approval', 'hr_approval',
        'date_requested', 'date_responded'
    )
    list_filter = (
        'leave_type', 'status', 'senior_partner_approval', 'managing_partner_approval', 'hr_approval',
        'start_date', 'end_date'
    )
    search_fields = (
        'user__username', 'leave_type', 'other_reason', 'reason', 'comments',
        'senior_partner_approval', 'managing_partner_approval', 'hr_approval'
    )

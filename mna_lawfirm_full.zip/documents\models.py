from django.db import models
from users.models import User
from clients.models import Client
from cases.models import Case
from django.core.exceptions import ValidationError

class Document(models.Model):
    DOCUMENT_TYPE_CHOICES = [
        ('pleading', 'Pleading'),
        ('evidence', 'Evidence'),
        ('contract', 'Contract'),
        ('invoice', 'Invoice'),
        ('court_order', 'Court Order'),
        ('other', 'Other'),
    ]
    title = models.CharField(max_length=255)
    file = models.FileField(upload_to='documents/')
    case = models.ForeignKey(Case, on_delete=models.CASCADE, related_name='documents', null=True, blank=True)
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='documents', null=True, blank=True)
    uploaded_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    document_type = models.CharField(max_length=50, choices=DOCUMENT_TYPE_CHOICES)
    description = models.TextField(blank=True, null=True)
    date_uploaded = models.DateTimeField(auto_now_add=True)
    is_confidential = models.BooleanField(default=False)
    required_for_case = models.BooleanField(default=False)
    tags = models.CharField(max_length=255, blank=True, null=True, help_text='Comma-separated tags for categorization and search')

    def clean(self):
        super().clean()
        if self.file and self.file.size > 10 * 1024 * 1024:
            raise ValidationError('File size must be under 10MB.')

    def __str__(self):
        return self.title

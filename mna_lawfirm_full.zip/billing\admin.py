from django.contrib import admin
from .models import Billing

@admin.register(Billing)
class BillingAdmin(admin.ModelAdmin):
    list_display = ('invoice_number', 'client', 'case', 'amount', 'status', 'due_date', 'date_issued', 'date_paid', 'tags', 'invoice_file')
    list_filter = ('status', 'due_date', 'date_issued', 'date_paid', 'tags')
    search_fields = ('invoice_number', 'client__user__username', 'case__title', 'description', 'tags')
